﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FileProcessor;
using System.Xml;
using System.Configuration;
using System.IO;
using System.Xml.Serialization;

namespace FileProcessEngine
{
    /// <summary>
    /// Requirements
    ///1. Read different file types
    ///2. Read for specific fields with in that file based on country
    ///3. The mapping values based on the country will be provided in mapping file having country --> field --> field name
    ///4. Store the datas in datastore
    ///5. Get the data based on local country format
    /// </summary>
    class Program
    {
        static void Main(string[] args)
        {
            string inputFolder = Path.Combine(ConfigurationManager.AppSettings["RootDirectory"],
                                            ConfigurationManager.AppSettings["InputFolder"]);

            //Process the different input files available in Input folder for USA
            string[] filesUSA = Directory.GetFiles( Path.Combine( inputFolder, "USA"));
            foreach (var file in filesUSA)
            {
                //Create text handler for USA file format
                BaseFileHandler handler = FactoryFileHandler.CreateHandler(FileTypes.Text, "USA");
                handler.ReadAndProcessFile(file);
                DisplayOutPut();
            }

            //Process the different input files available in Input folder for UK
            string[] filesUK = Directory.GetFiles(Path.Combine(inputFolder, "UK"));
            foreach (var file in filesUK)
            {
                //Create text handler for UK file format
                BaseFileHandler handler = FactoryFileHandler.CreateHandler(FileTypes.Text, "UK");
                handler.ReadAndProcessFile(file);
                DisplayOutPut();
            }

        }

        private static void DisplayOutPut()
        {
            string destinationLocation = Path.Combine(ConfigurationManager.AppSettings["RootDirectory"].ToString(),
                                                        ConfigurationManager.AppSettings["DestinationFolder"].ToString());

            var paySlips = DeserializeXMLFileToObject<PaySlip>(Path.Combine( destinationLocation , "SalaryTable.xml"));


            Console.WriteLine("=================Out put format Start=======================");
            Console.WriteLine(paySlips.ToString());
            Console.WriteLine("=================Out put format Ends=======================");
        }

        public static T DeserializeXMLFileToObject<T>(string XmlFilename)
        {
            T returnObject = default(T);
            if (string.IsNullOrEmpty(XmlFilename)) return default(T);

            try
            {
                StreamReader xmlStream = new StreamReader(XmlFilename);
                XmlSerializer serializer = new XmlSerializer(typeof(T));
                returnObject = (T)serializer.Deserialize(xmlStream);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error Occured:" + ex.ToString());
            }
            return returnObject;
        }
    }
}
