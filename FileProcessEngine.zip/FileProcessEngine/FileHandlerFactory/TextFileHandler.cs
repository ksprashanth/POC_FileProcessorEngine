﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Xml;
using System.Configuration;
using System.Xml.Serialization;

namespace FileProcessor
{
    /// <summary>
    /// Text File Handler for handling Text files
    /// </summary>
    public class TextFileHandler : BaseFileHandler
    {
        public TextFileHandler() : base() { }

        public TextFileHandler(ICountryMapper mapper) : base(mapper) { }
        /// <summary>
        /// This method reads the text file, processes and finally saves the data to xml file
        /// </summary>
        /// <param name="FileName"></param>
        public override void ReadAndProcessFile(string FileName)
        {
            //Logic to read the excel file should go here based on the mapping fields

            var mappings = _mapper.GetMappingFields();
            Console.WriteLine(string.Format("read and process Text File : {0} ", FileName));
            PaySlip paySlip = new PaySlip();
            string lineFound = "";

            foreach (var lineItem in mappings)
            {
                foreach (var line in File.ReadLines(FileName))
                {
                    if (line.Contains(lineItem.Value))
                    {
                        lineFound = line;
                        break;
                    }
                }
               
                if (string.IsNullOrEmpty(lineFound))
                   continue;

                string[] values = lineFound.Split('|');
                if (lineItem.Key == "BasicSalary")
                    paySlip.BasicSalary = double.Parse(values[1]);
                else if (lineItem.Key == "HRA")
                    paySlip.HRA = double.Parse(values[1]);
                else if (lineItem.Key == "SpecialAllowance")
                    paySlip.SpecialAllowance = double.Parse(values[1]);
                else if (lineItem.Key == "Deductions")
                    paySlip.Deductions = double.Parse(values[1]);
            }

            WritetoDB(paySlip);
        }

        /// <summary>
        /// this private method saves the data to xml file
        /// </summary>
        /// <param name="item"></param>
        private void WritetoDB(PaySlip item)
        {
            string destinationLocation = Path.Combine(ConfigurationManager.AppSettings["RootDirectory"].ToString(),
                                                       ConfigurationManager.AppSettings["DestinationFolder"].ToString());
            TextWriter writer = null;
            try
            {
                XmlSerializer serializer = new XmlSerializer(typeof(PaySlip));
                writer = new StreamWriter(Path.Combine(destinationLocation,"SalaryTable.xml"), false);
                serializer.Serialize(writer, item);
            }
            finally
            {
                if (writer != null)
                    writer.Close();
            }
        }

    }
}
