﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FileProcessor
{
    /// <summary>
    /// BaseFileHander abstaract class acts as a base class for creating different handlers like XmlHandler, WordHander, TextHandler etc
    /// </summary>
    public abstract class BaseFileHandler
    {
        protected ICountryMapper _mapper;
        public BaseFileHandler(){}
        public BaseFileHandler(ICountryMapper mapper)
        {
            _mapper = mapper;
        }
        public Dictionary<string, string> Mappper { get; set; }
        public void setCountryMapper(ICountryMapper mapper) {
            _mapper = mapper;
        }
        /// <summary>
        /// This method reads, processes the files and finally saves the data to datastore 
        /// </summary>
        /// <param name="fileName"></param>
        public virtual void ReadAndProcessFile(string fileName)
        {
            var mappings = _mapper.GetMappingFields();
            Console.WriteLine(string.Format( "read and process {0} file", fileName));
        }
    }
}
