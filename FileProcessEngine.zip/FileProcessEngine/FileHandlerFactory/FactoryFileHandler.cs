﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FileProcessor
{
    /// <summary>
    /// current supported file types
    /// </summary>
    public enum FileTypes
    {
        Xls,
        Text,
        Excel,
        Pdf,
        Xml
    }
    /// <summary>
    /// FactoryFileHandler class acts as a factory for creating different FileHandlers based on file type and country
    /// </summary>
    public static class FactoryFileHandler
    {
        private static Dictionary<FileTypes, BaseFileHandler> handlers = new Dictionary<FileTypes, BaseFileHandler>();
        private static Dictionary<string, ICountryMapper> mappers = new Dictionary<string, ICountryMapper>();
        public static BaseFileHandler CreateHandler(FileTypes fileType, string country)
        {
            if(handlers.Count == 0)
            {
                handlers.Add(FileTypes.Excel, new ExcelFileHandler());
                handlers.Add(FileTypes.Pdf, new PDFFileHandler());
                handlers.Add(FileTypes.Xml, new XmlFileHandler());
                handlers.Add(FileTypes.Text, new TextFileHandler());
            }

            if(mappers.Count == 0)
            {
                mappers.Add("USA", new USAMapper());
                mappers.Add("UK", new UKMapper());
            }

            var handler= handlers[fileType];
            handler.setCountryMapper(mappers[country]);
            return handler;
        }
    }
}
