﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FileProcessor
{
    /// <summary>
    /// PDF File Handler for handling pdf files
    /// </summary>
    public class PDFFileHandler : BaseFileHandler
    {
        public PDFFileHandler() : base() { }

        public PDFFileHandler(ICountryMapper mapper) : base(mapper) { }
        public override void ReadAndProcessFile(string FileName)
        {
            //Logic to read teh excel file should go here based on the mapping fields
            Console.WriteLine(string.Format("read and process PDF File : {0} ", FileName));
        }

    }
}
