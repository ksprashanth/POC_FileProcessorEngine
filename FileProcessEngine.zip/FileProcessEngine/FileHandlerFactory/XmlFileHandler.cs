﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FileProcessor
{
    /// <summary>
    /// XML File Handler for handling Xml files
    /// </summary>
    public class XmlFileHandler : BaseFileHandler
    {
        public XmlFileHandler() : base() { }

        public XmlFileHandler(ICountryMapper mapper) : base(mapper) { }
        public override void ReadAndProcessFile(string FileName)
        {
            var mappings = _mapper.GetMappingFields();
            //Logic to read teh excel file should go here based on the mapping fields
            Console.WriteLine(string.Format("read and process Xml File : {0} ", FileName));
        }

    }
}
