﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FileProcessor
{
    /// <summary>
    /// Excel File Handler for handling MS excel files
    /// </summary>
    public class ExcelFileHandler : BaseFileHandler
    {
        public ExcelFileHandler() : base() { }

        public ExcelFileHandler(ICountryMapper mapper) : base(mapper) { }
        public override void ReadAndProcessFile(string FileName)
        {
            var mappings = _mapper.GetMappingFields();
            //Logic to read teh excel file should go here based on the mapping fields
            Console.WriteLine(string.Format("read and process Excel File : {0} ", FileName));
        }

    }
}
