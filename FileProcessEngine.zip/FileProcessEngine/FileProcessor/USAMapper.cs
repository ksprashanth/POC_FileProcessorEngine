﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace FileProcessor
{
    public class USAMapper : ICountryMapper
    {
        public Dictionary<string, string> GetMappingFields()
        {
            Dictionary<string, string> mappingValues = new Dictionary<string, string>();
            XmlDocument docMapper = new XmlDocument();
            docMapper.Load(@"C:\Prashanth\FileProcessEngine\FileProcessor\MappingFields.xml");

            var elements = docMapper.GetElementsByTagName("country");

            foreach (XmlNode node in elements)
            {
                if(node.Attributes["name"].Value == "USA")
                {
                    mappingValues.Add("BasicSalary", node.SelectSingleNode("BasicSalary").InnerText);
                    mappingValues.Add("HRA", node.SelectSingleNode("HRA").InnerText);
                    mappingValues.Add("SpecialAllowance", node.SelectSingleNode("SpecialAllowance").InnerText);
                    mappingValues.Add("Deductions", node.SelectSingleNode("Deductions").InnerText);
                }
            }

            return mappingValues;
        }
    }
}
